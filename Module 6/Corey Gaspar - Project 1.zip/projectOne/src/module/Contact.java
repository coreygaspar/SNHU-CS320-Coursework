package module;

public class Contact {
    // declaring all fields
    private final String contactID; // cannot be changed
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactID, String firstName, String lastName, String phone, String address) {
        // contactID validation
        if (contactID == null || contactID.length() > 10) {
            throw new IllegalArgumentException("Invalid Contact ID: cannot be null or greater than 10 characters.");
        }
        this.contactID = contactID;

        // firstName validation
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid First Name: cannot be null or greater than 10 characters.");
        }
        this.firstName = firstName;

        // lastName validation
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid Last Name: cannot be null or greater than 10 characters.");
        }
        this.lastName = lastName;

        // phone validation
        if (phone == null || phone.length() != 10 || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Invalid Phone Number: must be 10 digits.");
        }
        this.phone = phone;

        // address validation
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid Address: cannot be null or greater than 30 characters.");
        }
        this.address = address;
    }

    // getters
    public String getContactID() { return contactID; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }

    // setters
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid First Name: cannot be null or greater than 10 characters.");
        }
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid Last Name: cannot be null or greater than 10 characters.");
        }
        this.lastName = lastName;
    }

    public void setPhone(String phone) {
        if (phone == null || phone.length() != 10 || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Invalid Phone Number: must be 10 digits.");
        }
        this.phone = phone;
    }

    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid Address: cannot be null or greater than 30 characters.");
        }
        this.address = address;
    }
}
