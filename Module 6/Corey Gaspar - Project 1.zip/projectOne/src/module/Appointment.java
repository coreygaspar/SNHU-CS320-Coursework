package module;

// used to check if date is in the past
import java.util.Date;

public class Appointment 
{
	// declaring all fields
	private final String appointmentID; // cannot be updated
	private Date appointmentDate;
	private String description;
	
	public Appointment(String appointmentID, Date appointmentDate, String description) 
	{
		// appointmentID validation
		// cannot be null OR longer than 10 characters
		if(appointmentID == null || appointmentID.length() > 10)
		{
			throw new IllegalArgumentException("Invalid Appointment ID");
		}
		this.appointmentID = appointmentID; // add to field
		
		// appointmentDate validation
		// cannot be null OR before today's date
		if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid Appointment Date");
        }
        this.appointmentDate = appointmentDate; // add to field
        
        // description validation
     	// cannot be null OR longer than 50 characters
     	if(description == null || description.length() > 50)
     	{
     		throw new IllegalArgumentException("Invalid Description");
     	}
     	this.description = description; // add to field
	}
	
	// getters
    public String getAppointmentID() { return appointmentID; }
    public Date getAppointmentDate() { return appointmentDate; }
    public String getDescription() { return description; }

    // setters for fields that can be modified
    public void setAppointmentDate(Date appointmentDate) {
        if(appointmentDate == null || appointmentDate.before(new Date()))
        {
            throw new IllegalArgumentException("Invalid Appointment");
        }
        this.appointmentDate = appointmentDate;
    }

    public void setDescription(String description) {
        if(description == null || description.length() > 50)
        {
            throw new IllegalArgumentException("Invalid Description");
        }
        this.description = description;
    }
}