package module;

public class Task 
{
	// Declaring all fields
	private final String taskID; // Ensures that taskID cannot be changed
	private String name;
	private String description;
	
	public Task(String taskID, String name, String description) 
	{
		// taskID validation
		// Ensures that taskID is not null or longer than 10 characters
		if(taskID == null || taskID.length() > 10) 
		{
			throw new IllegalArgumentException("Invalid Task ID");
		}
		this.taskID = taskID;
		
		// name validation
		// Ensures that name is not null or longer than 20 characters
		if(name == null || name.length() > 20)
		{
			throw new IllegalArgumentException("Invalid Name");
		}
		this.name = name;
		
		//description validation
		//Ensures that description is not null or longer than 50 characters
		if(description == null || description.length() > 50)
		{
			throw new IllegalArgumentException("Invalid Description");
		}
		this.description = description;
	}
	
	// getters
	public String getTaskID() {return taskID;}
	public String getName() {return name;}
	public String getDescription() {return description;}
	
	// setters (only for the fields that can be modified)
	public void setName(String name)
	{
		if(name == null || name.length() > 20)
		{
			throw new IllegalArgumentException("Invalid Name");
		}
		this.name = name;
	}
	
	public void setDescription(String description)
	{
		if(description == null || description.length() > 50)
		{
			throw new IllegalArgumentException("Invalid Description");
		}
		this.description = description;
	}
}