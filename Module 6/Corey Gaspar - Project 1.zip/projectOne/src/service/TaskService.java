package service;
import module.Task;

import java.util.HashMap;
import java.util.Map;

public class TaskService
{
	/* Store tasks in memory
	 * Good for this project but would like a more efficient method */
	private Map<String, Task> tasks = new HashMap<>();
	
	// Add a new task
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskID())) {
            throw new IllegalArgumentException("Task already exists");
        }
        tasks.put(task.getTaskID(), task);
    }

    // Delete a task by ID
    public void deleteTask(String taskID) {
        if (!tasks.containsKey(taskID)) {
            throw new IllegalArgumentException("Task not found");
        }
        tasks.remove(taskID);
    }

    // Update name for unique task ID
    public void updateName(String taskID, String name) {
        Task task = tasks.get(taskID);
        if (task == null) {
            throw new IllegalArgumentException("Task not found");
        }
        task.setName(name);
    }

    // Update description for unique task ID
    public void updateDescription(String taskID, String description) {
        Task task = tasks.get(taskID);
        if (task == null) {
            throw new IllegalArgumentException("Task not found");
        }
        task.setDescription(description);
    }
}