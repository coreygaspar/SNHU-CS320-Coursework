package service;
import module.Appointment;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService 
{

    // Store appointments using Map
    private final Map<String, Appointment> appointments = new HashMap<>();

    // Add new appointment by ID
    public void addAppointment(Appointment appointment) 
    {
        if (appointments.containsKey(appointment.getAppointmentID())) 
        {
            throw new IllegalArgumentException("Appointment ID already exists");
        }
        appointments.put(appointment.getAppointmentID(), appointment);
    }

    // Delete appointment by ID
    public void deleteAppointment(String appointmentID) 
    {
        if (!appointments.containsKey(appointmentID)) 
        {
            throw new IllegalArgumentException("Appointment ID not found");
        }
        appointments.remove(appointmentID);
    }
}