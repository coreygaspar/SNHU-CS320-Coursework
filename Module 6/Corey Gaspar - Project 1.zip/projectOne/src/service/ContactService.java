package service;
import module.Contact;

import java.util.HashMap;
import java.util.Map;

public class ContactService {

    // Store contacts in memory
    private Map<String, Contact> contacts = new HashMap<>();

    // Add a new contact
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }
        contacts.put(contact.getContactID(), contact);
    }

    // Delete a contact by ID
    public void deleteContact(String contactID) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found: " + contactID);
        }
        contacts.remove(contactID);
    }

    // Update firstName
    public void updateFirstName(String contactID, String firstName) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found: " + contactID);
        }
        contact.setFirstName(firstName);
    }

    // Update lastName
    public void updateLastName(String contactID, String lastName) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found: " + contactID);
        }
        contact.setLastName(lastName);
    }

    // Update phone
    public void updatePhone(String contactID, String phone) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found: " + contactID);
        }
        contact.setPhone(phone);
    }

    // Update address
    public void updateAddress(String contactID, String address) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found: " + contactID);
        }
        contact.setAddress(address);
    }
}