/**
 * 
 */
/**
 * 
 */
module projectOne {
	requires org.junit.jupiter.api;
}