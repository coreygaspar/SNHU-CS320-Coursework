package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import module.Appointment;
import service.AppointmentService;

class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment appointment;

    // Helper method to get a valid future date
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        return cal.getTime();
    }

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
        appointment = new Appointment("A123", getFutureDate(), "Initial description");
    }

    @Test
    void testAddAppointment() {
        service.addAppointment(appointment); // add appointment
        // adding appointment with the same ID will throw exception
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appointment));
    }

    @Test
    void testDeleteAppointment() {
        service.addAppointment(appointment); // add appointment normally
        service.deleteAppointment("A123"); // deletes appointment by ID
        // deleting appointment with a non-existent ID will throw exception
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("A123"));
    }
}
