package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import module.Contact;
import service.ContactService;

public class ContactServiceTest {

    private ContactService service;
    private Contact contact;

    @BeforeEach
    void setUp() {
        service = new ContactService();
        contact = new Contact("12345", "FirstName", "LastName", "1234567890", "123 Street St");
    }

    @Test
    void testAddContact() {
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact));
    }

    @Test
    void testDeleteContact() {
        service.addContact(contact);
        service.deleteContact("12345");
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("12345"));
    }

    @Test
    void testUpdateFirstName() {
        service.addContact(contact);
        service.updateFirstName("12345", "NewName");
        assertEquals("NewName", contact.getFirstName());
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("999", "Invalid"));
    }

    @Test
    void testUpdateLastName() {
        service.addContact(contact);
        service.updateLastName("12345", "NewLast");
        assertEquals("NewLast", contact.getLastName());
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("999", "Invalid"));
    }

    @Test
    void testUpdatePhone() {
        service.addContact(contact);
        service.updatePhone("12345", "0987654321");
        assertEquals("0987654321", contact.getPhone());
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("999", "1234567890"));
    }

    @Test
    void testUpdateAddress() {
        service.addContact(contact);
        service.updateAddress("12345", "456 Road Ave");
        assertEquals("456 Road Ave", contact.getAddress());
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("999", "789 Blvd"));
    }
}
