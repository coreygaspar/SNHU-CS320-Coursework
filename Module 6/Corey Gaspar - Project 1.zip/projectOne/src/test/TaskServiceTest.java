package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import module.Task;
import service.TaskService;

class TaskServiceTest {

    private TaskService service;
    private Task task;

    @BeforeEach
    void setUp() {
    	// Initialize new TaskService and create a sample task before each test
        service = new TaskService();
        task = new Task("12345", "TaskName", "Task description");
    }

    @Test
    void testAddTask() {
        service.addTask(task); // Add task normally
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task)); // duplicate
    }

    @Test
    void testDeleteTask() {
        service.addTask(task); // Add task normally
        service.deleteTask("12345"); // delete task based on taskID
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("12345")); // already deleted
    }

    @Test
    void testUpdateName() {
        service.addTask(task); // Add task normally
        service.updateName("12345", "NewTaskName"); // update name for taskID
        assertEquals("NewTaskName", task.getName()); //verify that name updated
    }

    @Test
    void testUpdateDescription() {
        service.addTask(task); // Add task normally
        // update description
        service.updateDescription("12345", "New task description");
        // verify that description updated
        assertEquals("New task description", task.getDescription());
    }

    @Test
    void testUpdateInvalidTaskID() {
    	// attempting to update a task with a non-existing ID should throw error
        assertThrows(IllegalArgumentException.class, () -> service.updateName("999", "Name"));
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("999", "Desc"));
    }
}
