package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import module.Contact;

public class ContactTest {

    // Valid contact creation
    @Test
    void testValidContactCreation() {
        Contact c = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("12345", c.getContactID());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Main St", c.getAddress());
    }

    // Min/max boundary test
    @Test
    void testBoundaryContactFields() {
        // Minimum
        Contact min = new Contact("1", "A", "B", "0123456789", "C");
        assertEquals("1", min.getContactID());
        assertEquals("A", min.getFirstName());
        assertEquals("B", min.getLastName());
        assertEquals("0123456789", min.getPhone());
        assertEquals("C", min.getAddress());

        // Maximum
        Contact max = new Contact("1234567890", "ABCDEFGHIJ", "KLMNOPQRST", 
                                  "9876543210", "123456789012345678901234567890");
        assertEquals("1234567890", max.getContactID());
        assertEquals("ABCDEFGHIJ", max.getFirstName());
        assertEquals("KLMNOPQRST", max.getLastName());
        assertEquals("9876543210", max.getPhone());
        assertEquals("123456789012345678901234567890", max.getAddress());
    }

    // Invalid constructor
    @Test
    void testConstructorInvalid() {
        // contactID
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "John", "Doe", "1234567890", "123 St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "John", "Doe", "1234567890", "123 St"));

        // firstName
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", null, "Doe", "1234567890", "123 St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "FirstNameTooLong", "Doe", "1234567890", "123 St"));

        // lastName
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", null, "1234567890", "123 St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "LastNameTooLong", "1234567890", "123 St"));

        // phone
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "Doe", null, "123 St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "Doe", "12345", "123 St"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "Doe", "abcdefghij", "123 St"));

        // address
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "Doe", "1234567890", null));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "Doe", "1234567890", "1234567890123456789012345678901"));
    }

    // Valid setter
    @Test
    void testSettersValid() {
        Contact c = new Contact("1", "John", "Doe", "1234567890", "123 St");

        c.setFirstName("Jane");
        assertEquals("Jane", c.getFirstName());

        c.setLastName("Smith");
        assertEquals("Smith", c.getLastName());

        c.setPhone("0987654321");
        assertEquals("0987654321", c.getPhone());

        c.setAddress("456 Oak St");
        assertEquals("456 Oak St", c.getAddress());
    }

    // Invalid setter
    @Test
    void testSettersInvalid() {
        Contact c = new Contact("1", "John", "Doe", "1234567890", "123 St");

        // firstName invalid
        c.setFirstName("Bob"); // valid to cover "if false" branch
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName("FirstNameTooLong"));

        // lastName invalid
        c.setLastName("Billy");
        assertThrows(IllegalArgumentException.class, () -> c.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName("LastNameTooLong"));

        // phone invalid
        c.setPhone("1234567890");
        assertThrows(IllegalArgumentException.class, () -> c.setPhone(null));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("12345"));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("abcdefghij"));

        // address invalid
        c.setAddress("123 Main St.");
        assertThrows(IllegalArgumentException.class, () -> c.setAddress(null));
        assertThrows(IllegalArgumentException.class, () -> c.setAddress("1234567890123456789012345678901"));
    }
}
