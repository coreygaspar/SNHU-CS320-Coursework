package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import module.Task;

class TaskTest {

	// Testing a valid task
    @Test
    void testValidTaskCreation() {
        Task t = new Task("12345ABC", "TaskName", "This is a description.");
        assertEquals("12345ABC", t.getTaskID());
        assertEquals("TaskName", t.getName());
        assertEquals("This is a description.", t.getDescription());
    }
    
    // Test invalid taskID
    @Test
    void testInvalidTaskID() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Desc")); // taskID is null
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Desc")); // taskID > 10 chars
    }

    // Test invalid name
    @Test
    void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> new Task("123", null, "Desc")); // name is null
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "ReallyReallyReallyReallyReallyReallyLongName", "Desc")); // name > 20 chars
    }

    // Test invalid description
    @Test
    void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "Name", null)); // description is null
        assertThrows(IllegalArgumentException.class, () -> new Task("123", "Name", "This is a really long description and will most likely throw an illegal argument exception because of its length.")); // description > 50 chars
    }

    // Test setters
    @Test
    void testSetters() {
        Task t = new Task("123", "Name", "Desc");
        t.setName("NewName");
        assertEquals("NewName", t.getName());
        t.setDescription("New description");
        assertEquals("New description", t.getDescription());
    }

    // Test invalid values in setters
    @Test
    void testInvalidSetters() {
        Task t = new Task("123", "Name", "Desc");
        assertThrows(IllegalArgumentException.class, () -> t.setName(null));
        assertThrows(IllegalArgumentException.class, () -> t.setName("ReallyReallyReallyReallyReallyReallyLongName"));
        assertThrows(IllegalArgumentException.class, () -> t.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> t.setDescription("This is a really long description and will most likely throw an illegal argument exception because of its length."));
    }


}
