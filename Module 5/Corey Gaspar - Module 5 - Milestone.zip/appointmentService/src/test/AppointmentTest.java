package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import appointment.Appointment;

import java.util.Date;
import java.util.Calendar;

class AppointmentTest {

	// Helper method to get a future date (1 day ahead)
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, 1);
        return cal.getTime();
    }

    // Helper method to get a past date (1 day prior)
    private Date getPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1);
        return cal.getTime();
    }

    // Testing a valid appointment
    @Test
    void testValidAppointmentCreation() {
        Appointment appt = new Appointment("A123", getFutureDate(), "This is a description.");
        assertEquals("A123", appt.getAppointmentID());
        assertEquals("This is a description.", appt.getDescription());
        assertNotNull(appt.getAppointmentDate());
    }

    // Test invalid appointmentID
    @Test
    void testInvalidAppointmentID() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, getFutureDate(), "This is a description.")); // ID is null
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", getFutureDate(), "This is a description.")); // ID > 10 chars
    }

    // Test invalid appointmentDate
    @Test
    void testInvalidAppointmentDate() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A123", null, "This is a description.")); // date is null
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A123", getPastDate(), "This is a description.")); // date in past
    }

    // Test invalid description
    @Test
    void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A123", getFutureDate(), null)); // description is null
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A123", getFutureDate(),
                "Really really really really really really really really really really really really long description.")); // > 50 chars
    }

    // Test setters
    @Test
    void testSetters() {
        Appointment appt = new Appointment("A123", getFutureDate(), "This is a description.");

        // Set new valid description
        appt.setDescription("Updated description");
        assertEquals("Updated description", appt.getDescription());

        // Set new valid date
        Date newDate = getFutureDate();
        appt.setAppointmentDate(newDate);
        assertEquals(newDate, appt.getAppointmentDate());
    }

    // Test invalid values in setters
    @Test
    void testInvalidSetters() {
        Appointment appt = new Appointment("A123", getFutureDate(), "This is a description.");

        // Invalid description
        assertThrows(IllegalArgumentException.class, () -> appt.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> appt.setDescription(
                "Really really really really really really really really really really really really long description."));

        // Invalid date
        assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(null));
        assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(getPastDate()));
    }

}
