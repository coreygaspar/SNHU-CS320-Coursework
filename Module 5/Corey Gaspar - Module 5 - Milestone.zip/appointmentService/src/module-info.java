/**
 * 
 */
/**
 * 
 */
module appointmentService {
	requires org.junit.jupiter.api;
}