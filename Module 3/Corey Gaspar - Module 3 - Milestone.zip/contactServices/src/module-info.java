/**
 * 
 */
/**
 * 
 */
module contactServices {
	requires org.junit.jupiter.api;
}