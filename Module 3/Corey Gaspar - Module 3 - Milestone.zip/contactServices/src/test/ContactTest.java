package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import contact.Contact;

public class ContactTest {

    // Test valid creation
    @Test
    void testValidContactCreation() {
        Contact c = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("12345", c.getContactID());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Main St", c.getAddress());
    }

    // Test invalid contactID
    @Test
    void testInvalidContactID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe", "1234567890", "123 Main St");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St"); // >10 chars
        });
    }

    // Test invalid firstName
    @Test
    void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", null, "Doe", "1234567890", "123 Main St");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "JohnathanLong", "Doe", "1234567890", "123 Main St"); // >10 chars
        });
    }

    // Test invalid lastName
    @Test
    void testInvalidLastName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "John", null, "1234567890", "123 Main St");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "John", "LongLastNameHere", "1234567890", "123 Main St"); // > 10 chars
        });
    }

    // Test invalid phone
    @Test
    void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "John", "Doe", "12345", "123 Main St"); // too short
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "John", "Doe", "abcdefghij", "123 Main St"); // not digits
        });
    }

    // Test invalid address
    @Test
    void testInvalidAddress() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "John", "Doe", "1234567890", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "John", "Doe", "1234567890", "This address is way too long to be valid");
        });
    }

    // Test setters
    @Test
    void testSetters() {
        Contact c = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        c.setFirstName("Jane");
        assertEquals("Jane", c.getFirstName());
        c.setLastName("Smith");
        assertEquals("Smith", c.getLastName());
        c.setPhone("0987654321");
        assertEquals("0987654321", c.getPhone());
        c.setAddress("456 Oak St");
        assertEquals("456 Oak St", c.getAddress());
    }
}
