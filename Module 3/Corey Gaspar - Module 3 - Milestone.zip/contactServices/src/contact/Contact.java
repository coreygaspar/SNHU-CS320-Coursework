package contact;

public class Contact 
{
    // declaring all fields
	private final String contactID; // cannot be changed
	private String firstName;
	private String lastName;
	private String phone;
	private String address;


	public Contact (String contactID, String firstName, String lastName, String 	phone, String address) 
	{
		// contactID validation
		// checks to see if contactID is null OR if length is greater than 10
		if(contactID == null || contactID.length() > 10) 
		{
			throw new IllegalArgumentException("Invalid contact ID");
		}
		this.contactID = contactID; // assigns Contact ID to field
		
		
		// firstName validation
		// checks to see if firstName is null OR if length is greater than 10
		if(firstName == null || firstName.length() > 10)
		{
			throw new IllegalArgumentException("Invalid First Name");
		}
		this.firstName = firstName; // assigns First Name to field
		
		
		// lastName validation
		// checks to see if lastName is null OR if length is greater than 10
		if(lastName == null || lastName.length() > 10)
		{
		throw new IllegalArgumentException("Invalid Last Name");
		}
		this.lastName = lastName; // assigns Last Name to field
		
		
		// phone validation
		// checks to see if phone is null OR if length is NOT 10 OR no digits
		if(phone == null || phone.length() != 10 || !phone.matches("\\d{10}"))
		{
		throw new IllegalArgumentException("Invalid Phone Number");
		}
		this.phone = phone; // assigns Phone Number to field
		
		
		// address validation
		// checks to see if address is null OR if length is greater than 30
		if(address == null || address.length() > 30)
		{
		throw new IllegalArgumentException("Invalid Address");
		}
		this.address = address; // assigns Address to field
	}
	// getters
    public String getContactID() { return contactID; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }

    // setters for fields that can be modified
    public void setFirstName(String firstName) {
        if(firstName == null || firstName.length() > 10)
            throw new IllegalArgumentException("Invalid First Name");
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        if(lastName == null || lastName.length() > 10)
            throw new IllegalArgumentException("Invalid Last Name");
        this.lastName = lastName;
    }

    public void setPhone(String phone) {
        if(phone == null || phone.length() != 10 || !phone.matches("\\d{10}"))
            throw new IllegalArgumentException("Invalid Phone Number");
        this.phone = phone;
    }

    public void setAddress(String address) {
        if(address == null || address.length() > 30)
            throw new IllegalArgumentException("Invalid Address");
        this.address = address;
    }
}
